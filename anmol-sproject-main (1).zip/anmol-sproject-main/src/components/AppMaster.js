import React from 'react'
import Navbar from './horizontalNav/Navbar';

const AppMaster = () => {
  return (
    <>
    <Navbar/>
    
    <h1 style={{textAlign:"center"}}>AppMaster</h1>

    </>
  )
}

export default AppMaster;