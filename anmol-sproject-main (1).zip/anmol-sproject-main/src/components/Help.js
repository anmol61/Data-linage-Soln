import React from 'react'
import Navbar from './horizontalNav/Navbar';

const Help = () => {
  return (
    <>
    
    <Navbar/>
    <h1 style={{textAlign:"center"}}>Help</h1>

    </>
  )
}

export default Help;