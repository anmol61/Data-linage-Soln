import React from 'react'
import Navbar from './horizontalNav/Navbar';

const DataFlow = () => {
  return (
<>
<Navbar/>
<h1 style={{textAlign:"center"}}>DataFlow</h1>



</>  )
}

export default DataFlow;