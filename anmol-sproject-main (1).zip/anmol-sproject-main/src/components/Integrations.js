import React from 'react'
import Navbar from './horizontalNav/Navbar';

const Integrations = () => {
  return (
    <>
    <Navbar/>
    <h1 style={{textAlign:"center"}}>Integrations</h1>

    </>
  )
}

export default Integrations;