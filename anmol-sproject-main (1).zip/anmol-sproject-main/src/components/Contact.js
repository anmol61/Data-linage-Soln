import React from 'react'
import Navbar from './horizontalNav/Navbar';

const Contact = () => {
  return (
    <>
<Navbar/>
    
    <h1 style={{textAlign:"center"}}>Contact US</h1>

    </>  )
}

export default Contact;