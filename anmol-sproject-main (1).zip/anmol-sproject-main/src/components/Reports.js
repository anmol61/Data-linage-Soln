import React from 'react'
import Navbar from './horizontalNav/Navbar';

const Reports = () => {
  return (
    <>
    <Navbar/>
    
    <h1 style={{textAlign:"center"}}>Reports</h1>

    </>
  )
}

export default Reports;