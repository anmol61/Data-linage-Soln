import React from 'react'

const AppMaster = () => {
  return (
    <h1 style={{textAlign:"center"}}>AppMaster</h1>
  )
}

export default AppMaster;