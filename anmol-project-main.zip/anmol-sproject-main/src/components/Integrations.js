import React from 'react'

const Integrations = () => {
  return (
    <h1 style={{textAlign:"center"}}>Integrations</h1>
  )
}

export default Integrations;