import React from 'react'

const Reports = () => {
  return (
    <h1 style={{textAlign:"center"}}>Reports</h1>
  )
}

export default Reports;