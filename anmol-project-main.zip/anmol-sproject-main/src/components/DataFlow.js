import React from 'react'

const DataFlow = () => {
  return (
    <h1 style={{textAlign:"center"}}>DataFlow</h1>
  )
}

export default DataFlow;