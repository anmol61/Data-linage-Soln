import React from 'react'

const Help = () => {
  return (
    <h1 style={{textAlign:"center"}}>Help</h1>
  )
}

export default Help;